const iconClasses = [
'fa-atom','fa-frog','fa-feather-alt','fa-cogs','fa-anchor','fa-fan',
'fa-bolt','fa-hat-wizard','fa-apple-alt','fa-bell','fa-bomb','fa-brain'
];

const cardsBoard = document.querySelector('#cards');
const allCards = document.querySelectorAll('.card');
const nextCard = document.querySelector('#next-card');
const yourScore = document.querySelector('#score');
const restartButton = document.querySelector('.restart');

let totalMoves = 0;
let hiddenCards = [];
let wantedIconClass = '';
let canClick = true;

let shuffle = function(array) {
  let currentIndex = array.length, temporaryValue, randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

function onCardSelected(event) {
  if (event.target.tagName !== 'LI'|| hiddenCards.length === 0) 
  	return;
  if(!canClick)
  	return;
  if (event.target.className.indexOf('matched') !== -1) {
    return;
  }
  
  canClick = false;
  totalMoves++;
  yourScore.innerHTML = totalMoves;
  event.target.classList.add('show');

  if (event.target.children[0].className.indexOf(wantedIconClass) !== -1) {
    event.target.classList.add('matched');
    hiddenCards = hiddenCards.filter(iconClass => iconClass !== wantedIconClass);
    setNextCardIcon();
    winCheck();
    canClick = true;
  } else {
    setTimeout(function() {
      event.target.classList.remove('show');
      canClick = true;
    }, 500);
  }
} 

function winCheck() {
  if (hiddenCards.length === 0) {
    setTimeout(function() {
      alert('Winner! You took '+totalMoves+'moves.');
    });
  }
}

function resetGame() {

  hiddenCards = shuffle(iconClasses);
  setNextCardIcon();

  totalMoves = 0;
  yourScore.textContent = 0;

  allCards.forEach(function(element,index,array) {
    element.classList.remove('matched');
    element.classList.remove('show');
    element.children[0].className = "fas " + hiddenCards[index];
  })
}

function setNextCardIcon() {
  let random = Math.floor(Math.random() * hiddenCards.length);
  if (hiddenCards.length > 0) {
    wantedIconClass = hiddenCards[random];
    nextCard.children[0].className = "fas " + wantedIconClass;
  }
}
cardsBoard.addEventListener('click', onCardSelected);
restartButton.addEventListener('click', resetGame);

resetGame();